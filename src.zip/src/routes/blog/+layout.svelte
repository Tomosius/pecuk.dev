<script lang="ts">
	let { children } = $props();
</script>

{@render children?.()}
