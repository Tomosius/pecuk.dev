// src/lib/index.ts
export * from './seo/seo';
export { default as Head } from './components/Head.svelte';
export { default as Navbar } from './components/Navbar.svelte';
export * from './content/index';