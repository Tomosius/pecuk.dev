pecukevicius@Tomass-MacBook-Air pecuk.dev % task lint
task: [lint:ts] npx eslint . --ext .ts,.svelte --max-warnings=0

/Users/pecukevicius/WebstormProjects/pecuk.dev/src/lib/components/ContentCard.svelte
  18:8  error  Found a link with a url that isn't resolved  svelte/no-navigation-without-resolve

✖ 1 problem (1 error, 0 warnings)

task: Failed to run task "lint": exit status 1